<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH.'/libraries/App_Controller.php';

class Login extends App_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->model("login_model");
	}

	public function index()
	{
		if($this->login_model->logged_in()){
			redirect('dashboard');
		}
		else{
			
			$this->form_validation->set_rules('username','Username', 'required');
			$this->form_validation->set_rules('password','Password', 'required');

			if($this->form_validation->run()==TRUE){

				 $username = $this->input->post("username", TRUE);
                 $password = MD5($this->input->post('password', TRUE));

                 $check = $this->login_model->check_login('user', array('username' => $username), array('password' => $password));

                 if($check == TRUE){

                 	foreach ($check as $apps) {

                        $session_data = array(
                            'user_id'   => $apps->user_id,
                            'user_name' => $apps->username,
                            'user_pass' => $apps->password,
                            'name' => $apps->nama,
                            'logged_in' => TRUE,
                        );

                        $this->session->set_userdata($session_data);

                        redirect('dashboard');
                    }

                 }else{

                 	$this->session->set_flashdata('error', 'Username atau password salah!');
                 	$dataHeader['judul'] = 'CodingCode Project | Login';

                 	$this->LoadViewsLogin('login', NULL, $dataHeader);
                 	
                 }

			}
			else{

				$dataHeader['judul'] = 'CodingCode Project | Login';

				$this->LoadViewsLogin('login', NULL, $dataHeader);

			}

		}

	}

	public function logout(){
		$this->session->sess_destroy();
		redirect(base_url());
	}

}