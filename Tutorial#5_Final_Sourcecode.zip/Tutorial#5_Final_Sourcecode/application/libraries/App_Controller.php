<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class App_Controller extends CI_Controller{

	function LoadViews($namaView="", $dataView=NULL, $dataHeader=NULL){

		$this->load->view('frame/header.php', $dataHeader);
		$this->load->view('frame/navbar.php');
		$this->load->view('frame/sidebar.php');
		$this->load->view($namaView, $dataView);
		$this->load->view('frame/footer.php');

	}

	function LoadViewsLogin($namaView="", $dataView=NULL, $dataHeader=NULL){

		$this->load->view('frame/header.php', $dataHeader);
		$this->load->view($namaView, $dataView);
		$this->load->view('frame/footer.php');

	}

}