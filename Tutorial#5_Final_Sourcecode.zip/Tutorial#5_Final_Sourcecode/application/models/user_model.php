<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class User_model extends CI_Model {

	function listuser(){
		
		$this->db->select('*');
		$this->db->from('user');
		return $this->db->get()->result();

	}

	function validate_username($username){

		$this->db->where('username', $username);
		$this->db->from('user');
		$query = $this->db->get();

		if($query->num_rows()==0){
			return true;
		}
		else
		{
			return false;
		}

	}

	function get_user_by_id($user_id){

		$this->db->select('*');
		$this->db->from('user');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();

		return $query->result_array();

	}

	function insert_user($postData){
		$validate = $this->validate_username($postData['username']);

		if($validate){
			$data = array(
				'username' => $postData['username'],
				'password' => md5($postData['password']),
				'nama' => $postData['nama']
			);

			$this->db->insert('user', $data);

			return array('status'=>'success');
		}
		else{

			return array('status'=>'duplikat');
		}
	}

	function update_user($postData){

		$dataUser = $this->get_user_by_id($postData['user_id']);
		if(strtolower($dataUser[0]['username']) == strtolower($postData['username'])){
			$validate = true;
		}
		else
		{
			$validate =  $this->validate_username($postData['username']);
		}

		if($validate){

			$data = array(
				'username' => $postData['username'],
				'nama' => $postData['nama']
			);

			$this->db->where('user_id', $postData['user_id']);
			$this->db->update('user', $data);

			return array('status' => 'success');
		}
		else{
			return array ('status' => 'duplikat');
		}		
	}

	function delete_user($user_id){

		$this->db->where('user_id', $user_id);
		$this->db->delete('user');

		return array('status' => 'success');

	}

}