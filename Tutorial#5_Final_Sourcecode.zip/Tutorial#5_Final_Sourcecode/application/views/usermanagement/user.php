<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content ">
            <!-- ============================================================== -->
            <!-- pageheader  -->
            <!-- ============================================================== -->
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h2 class="pageheader-title">User</h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end pageheader  -->
            <!-- ============================================================== -->
            <div class="row">
                <!-- ============================================================== -->
                <!-- data table  -->
                <!-- ============================================================== -->
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <?php if($this->session->flashdata('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $this->session->flashdata('success')?>
                        <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                        </a>
                    </div>
                    <?php endif;?>
                    <div class="card">
                        <div class="card-header d-flex">
                            <h5 class="mb-0">Data User</h5>
                            <div class="dropdown ml-auto">
                                <a class="toolbar" href="#" role="button" id="dropdownMenuLink5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="mdi mdi-dots-vertical"></i> </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink5">
                                    <a class="dropdown-item" href="#" onclick="tambah_user()" data-toggle="modal" data-target="#tambahUserModal">Tambah User</a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example" class="table table-striped table-bordered second" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Username</th>
                                            <th>Nama</th>
                                            <th>Tgl. Input</th>
                                            <th>#</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no=1; ?>
                                        <?php foreach($listuser as $listuser): ?>
                                            <tr>
                                                <td width="2%"><?=$no++?>.</td>
                                                <td width="20%"><?=$listuser->username?></td>
                                                <td width="30%"><?=$listuser->nama?></td>
                                                <td width="20%"><?=$listuser->tglinput?></td>
                                                <td width="28%">
                                                    <button type="button" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#editUserModal" onclick="edit_user('<?=$listuser->user_id?>','<?=$listuser->username?>','<?=$listuser->nama?>')">Edit</button>&nbsp;
                                                    <button type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#hapusUserModal" onclick="hapus_user('<?=$listuser->user_id?>','<?=$listuser->nama?>')">Hapus</button>
                                                </td>
                                            </tr>
                                        <?php endforeach;?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>No</th>
                                            <th>Username</th>
                                            <th>Nama</th>
                                            <th>Tgl. Input</th>
                                            <th>#</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end data table  -->
                <!-- ============================================================== -->
            </div>

            <div class="modal fade" id="tambahUserModal" tabindex="-1" role="dialog" aria-labelledby="tambahUserModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="tambahUserModalLabel">Tambah User</h5>
                            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                            </a>
                        </div>
                        <div class="modal-body">
                                <div class="form-group">
                                    <label for="username">Username</label>
                                    <input id="username" type="text" name="username" data-parsley-trigger="change" required="" placeholder="Masukkan Username" autocomplete="off" class="form-control">
                                    <label id="error_username" class="text-danger">Username tidak boleh kosong.</label>
                                    <label id="error_username2" class="text-danger">Username sudah ada.</label>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input id="password" type="password" name="password" placeholder="Masukkan Password" required="" class="form-control">
                                    <label id="error_password" class="text-danger">Password tidak boleh kosong.</label>
                                </div>
                                <div class="form-group">
                                    <label for="nama">Nama</label>
                                    <input id="nama" type="text" name="nama" data-parsley-trigger="change" required="" placeholder="Masukkan Nama" autocomplete="off" class="form-control">
                                    <label id="error_nama" class="text-danger">Nama tidak boleh kosong.</label>
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="button" class="btn btn-primary" id="btn_simpan">Simpan</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </a>
                        </div>
                        <div class="modal-body">
                                <div class="form-group">
                                    <label for="username_edit">Username</label>
                                    <input id="username_edit" type="text" name="username_edit" data-parsley-trigger="change" required="" placeholder="Masukkan Username" autocomplete="off" class="form-control">
                                    <label id="error_username_edit" class="text-danger">Username tidak boleh kosong.</label>
                                    <label id="error_username2_edit" class="text-danger">Username sudah ada.</label>
                                </div>
                                <div class="form-group">
                                    <label for="nama_edit">Nama</label>
                                    <input id="nama_edit" type="text" name="nama_edit" data-parsley-trigger="change" required="" placeholder="Masukkan Nama" autocomplete="off" class="form-control">
                                    <label id="error_nama_edit" class="text-danger">Nama tidak boleh kosong.</label>
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="button" class="btn btn-primary" id="btn_edit">Simpan</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="hapusUserModal" tabindex="-1" role="dialog" aria-labelledby="hapusUserModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="hapusUserModalLabel">Hapus User</h5>
                            <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </a>
                        </div>
                        <div class="modal-body">
                            <p>
                                Anda yakin menghapus user <label id="nama_username" style="color:blue;"></label> ?
                            </p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
                            <button type="button" class="btn btn-primary" id="btn_hapus">Ya</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- ============================================================== -->
    <!-- footer -->
    <!-- ============================================================== -->
    <div class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                     Edited By CodingCode Project | Copyright © 2018 Concept.
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="text-md-right footer-links d-none d-sm-block">
                        <a href="javascript: void(0);">About</a>
                        <a href="javascript: void(0);">Support</a>
                        <a href="javascript: void(0);">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end footer -->
    <!-- ============================================================== -->
</div>

<script src="<?=base_url('assets/js/app_user.js')?>"></script>