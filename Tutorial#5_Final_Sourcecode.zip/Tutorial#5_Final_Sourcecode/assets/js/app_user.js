window.onload = hideErrorValidation();

function hideErrorValidation(){

	$("#error_username").hide();
	$("#error_username2").hide();
	$("#error_password").hide();
	$("#error_nama").hide();

	$("#error_username_edit").hide();
	$("#error_username2_edit").hide();
	$("#error_nama_edit").hide();

}

function tambah_user(){

	hideErrorValidation();
	var username = document.getElementById('username').value ="";
	var password = document.getElementById('password').value ="";
	var nama = document.getElementById('nama').value ="";

	$("#btn_simpan").attr("onclick","tambah_user_detil()");

}

function tambah_user_detil(){
	var i = 0;
	var username  = $("#username").val().trim();
	var password = $("#password").val().trim();
	var nama = $("#nama").val().trim();

	if(username == ""){
		$("#error_username").show();
		i++;
	}

	if(password == ""){
		$("#error_password").show();
		i++;
	}

	if(nama == ""){
		$("#error_nama").show();
		i++;
	}

	if(i==0){

		$.ajax({
			url : $("#base_url").val() + "usermanagement/user/tambah_user",
			type : "post",
			dataType : "text",
			data : { username : username, password : password, nama : nama},
			success : function (result){
					var result = $.parseJSON(result);
					if(result.status=='success'){
						location.reload();
					}
					else if(result.status=='duplikat'){
						$("#error_username2").show();
					}
					else{
						alert("Terjadi Kesalahan!");
					}
			},
			error : ajax_error_handling

		});

	}

}

function edit_user(user_id, username, nama){

	hideErrorValidation();
	$("#username_edit").val(username);
	$("#nama_edit").val(nama);

	$("#btn_edit").attr("onclick","edit_user_detil("+ user_id +")");

}


function edit_user_detil(user_id){

	var i = 0;
	var username = $("#username_edit").val().trim();
	var nama = $("#nama_edit").val().trim();

	if(username == ""){
		$("#error_username_edit").show();
		i++;
	}

	if(nama == ""){
		$("#error_nama_edit").show();
		i++;
	}

	if(i==0){

		$.ajax({

			url : $("#base_url").val() + "usermanagement/user/edit_user",
			type : "post",
			dataType : "text",
			data : { username : username, nama : nama, user_id : user_id},
			success : function (result){
				var result = $.parseJSON(result);
				if(result.status=='success'){
					location.reload();
				}
				else if(result.status=='duplikat'){
					$("#error_username2_edit").show();
				}else{
					alert("Terjadi Kesalahan.");
				}
			},
			error : ajax_error_handling

		});

	}

}

function hapus_user(user_id, nama){

	$("#nama_username").html(nama);
	$("#btn_hapus").attr("onclick","hapus_user_detil('"+user_id+"', '"+nama+"')");

}

function hapus_user_detil(user_id, nama){
	$.ajax({

		url : $("#base_url").val() + "usermanagement/user/hapus_user",
		type : "post",
		dataType : "text",
		data : { user_id:user_id, nama:nama},
		success : function(result){
			var result = $.parseJSON(result);
			if(result.status=='success'){
				location.reload();
			}
			else{
				alert("Terjadi Kesalahan.");
			}
		},
		error : ajax_error_handling

	});
}


function ajax_error_handling(jqXHR, exception){
    if (jqXHR.status === 0) {
        alert('Not connect.\n Verify Network.');
    } else if (jqXHR.status == 404) {
        alert('Requested page not found. [404]');
    } else if (jqXHR.status == 500) {
        alert('Internal Server Error [500].');
    } else if (exception === 'parsererror') {
        alert('Requested JSON parse failed.');
    } else if (exception === 'timeout') {
        alert('Time out error.');
    } else if (exception === 'abort') {
        alert('Ajax request aborted.');
    } else {
        alert('Uncaught Error.\n' + jqXHR.responseText);
    }
}
